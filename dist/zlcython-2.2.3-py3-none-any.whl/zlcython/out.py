# -*- coding: utf-8 -*-
#!python3


import urllib.request as get__
import random
import time
############ v0.25.36 ###############
if True:
    if True:
        print('a')
############ v0.55.32 ###############
if True :
    if True :
        print ( ' a ' )
############ v0.96.45 ###############
if True:
    if True:
        print('a')
############ v1.00.01 ###############
if True:
    if True:
        print('a')
############ v1.20.33 ###############
if True:
    if True:
        print('a')
############ v1.55.23 ###############
if True:
    if True:
        print(get__.urlopen('https://baidu.com/').read())
###暂未发行## v1.93.45 ###暂未发行##### 此版本在二月底发行
def css选择器(啊,b):pass
if True:
    if True:
        print(css选择器(get__.urlopen('https://baidu.com/').获取网页内容),"title::text")
############ v1.96.23 ###############
if True:
    if True:
        print(random.randint( 10,30))
############ v2.0.0 ###############
if True:
    if True:
        def a():
            print('a')
if True:
    if True:
        from tkinter import *
        window=Tk()
        def 图形化标题(title):
            window.title(title)
        def 图形化窗口大小(width,height):
            window.geometry(str(width)+"x"+str(height))
        def 显示窗口():
            window.mainloop()
        def 显示文本(text,x=0,y=0):
            Label(window,text=text).place(x=x,y=y)
        def 显示文本框(text,x=0,y=0,width=None,height=None):
            Entry(window,text=text,width=width,height=height).place(x=x,y=y)
        def 显示按钮(text,command,x=0,y=0,width=None,height=None):
            Button(window,text=text,width=width,height=height,command=command).place(x=x,y=y)
        def 当窗口关闭时(command):
            def func():
                command()
                try:
                    window.destroy()
                except:pass
            window.protocol("WM_DELETE_WINDOW",func)
        def 图形化窗口位置(x,y):
            window.geometry("+"+str(x)+"+"+str(y))
        def 刷新窗口():
            window.update()
        
        图形化标题('标题')
        图形化窗口大小(300,300)
        显示按钮('a',a)
        当窗口关闭时(a)
        显示窗口()
############ v2.1.0 ###############
if True:
    if True:
        print(2 ** 3)
        print(2 % 3)
        print(2 + 3)
        print(2 * 3)
        time.sleep(3)
        print('a')
############ v2.2.0 ###############
if True:
    if True:
        def a():
            print('fhihguyknv')
            图形化窗口位置(random.randint(0,1800),random.randint(0,1000))
if True:
    if True:
        from tkinter import *
        window=Tk()
        def 图形化标题(title):
            window.title(title)
        def 图形化窗口大小(width,height):
            window.geometry(str(width)+"x"+str(height))
        def 显示窗口():
            window.mainloop()
        def 显示文本(text,x=0,y=0):
            l = Label(window,text=text)
            l.place(x=x,y=y)
        def 显示文本框(text,x=0,y=0,width=None,height=None):
            Entry(window,text=text,width=width,height=height).place(x=x,y=y)
        def 显示按钮(text,command,x=0,y=0,width=None,height=None):
            Button(window,text=text,width=width,height=height,command=command).place(x=x,y=y)
        def 当窗口关闭时(command):
            def func():
                command()
                try:
                    window.destroy()
                except:pass
            window.protocol("WM_DELETE_WINDOW",func)
        def 图形化窗口位置(x,y):
            window.geometry("+"+str(x)+"+"+str(y))
        def 刷新窗口():
            window.update()
        
        图形化标题('标题')
        图形化窗口大小(300,300)
        显示按钮('hello',a)
        当窗口关闭时(a)
        显示窗口()


