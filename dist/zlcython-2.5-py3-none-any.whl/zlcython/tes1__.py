# uncompyle6 version 3.8.0
# Python bytecode 3.10.0 (3439)
# Decompiled from: Python 3.10.4 (v3.10.4:9d38120e33, Mar 23 2022, 17:29:05) [Clang 13.0.0 (clang-1300.0.29.30)]
# Embedded file name: /Users/lucaszhang/Desktop/zlcy/zlcytopy.py
# Compiled at: 2022-06-06 14:07:42
# Size of source mod 2**32: 4142 bytes
